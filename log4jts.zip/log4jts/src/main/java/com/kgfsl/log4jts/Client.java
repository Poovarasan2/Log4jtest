package com.kgfsl.log4jts;

import org.apache.log4j.Logger;

public class Client
{
static Logger l=Logger.getLogger("Client.class");
public static void main(String args[])
{
 l.fatal("This is FATAL");
l.debug("This is Error DEBUG");
        l.warn("This is Error WARN");
        l.info("This is Error INFO");

}
}