package com.kgfsl.log4jtest;
import java.sql.*;

public class DBConnectionInsert {
public static void main(String[] args) {
Connection conn = DBConnection.getDBConnection();
try {
String query = "INSERT INTO employee(`emp_id`, `emp_name`, `emp_project`, `emp_company`) VALUES (1,'poov','ko','kgfsl')";
Statement statement = conn.createStatement();
PreparedStatement s1=conn.prepareStatement(query);
s1.executeUpdate(query); 
} catch (Exception e) {
e.printStackTrace();
}
}
}