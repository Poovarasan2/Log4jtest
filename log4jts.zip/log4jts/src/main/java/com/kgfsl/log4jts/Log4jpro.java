package com.kgfsl.log4jts;
import org.apache.log4j.Appender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;
import org.apache.log4j.ConsoleAppender;



public class Log4jpro
{
static Logger l=Logger.getLogger(Log4jpro.class.getName());
public static void main(String args[])
{
Layout l1=new SimpleLayout();
Appender a;
//Appender c=new ConsoleAppender(l1);
try
{
a=new FileAppender(l1,"my.txt",true);
l.addAppender(a);
//log4j.appender.FILE.DatePattern='.' yyyy-MM-dd;
//l.addAppender(c);
}
catch(Exception e)
{}
l.fatal("this is error msg");
System.out.println("executed successfully");
}
}